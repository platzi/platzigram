export default {
  db: {},
  secret: process.env.PLATZIGRAM_SECRET || 'pl4tzi' // never use default
}
