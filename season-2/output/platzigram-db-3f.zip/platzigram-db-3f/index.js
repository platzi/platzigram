module.exports = require('./lib/db')
