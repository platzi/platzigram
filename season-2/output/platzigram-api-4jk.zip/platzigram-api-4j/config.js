export default {
  db: {},
  secret: process.env.PLATZIGRAM_SECRET
}
