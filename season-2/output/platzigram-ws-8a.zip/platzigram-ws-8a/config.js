'use strict'

const config = {
  db: {
    host: 'localhost',
    port: 28015,
    db: 'platzigram'
  }
}

module.exports = config
